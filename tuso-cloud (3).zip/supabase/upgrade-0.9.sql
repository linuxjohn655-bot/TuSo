-- TuSo 0.9 upgrade: two accounts per device, profile gender and pronouns, founders, Mod / Head Mod roles, name rules.
-- Additive and safe to re-run. It does NOT touch your data. Run it in Supabase -> SQL Editor.
-- (Fresh installs get all of this from schema.sql already.)

-- ---------- profile: gender and pronouns (shown on the profile view) ----------
alter table public.profiles add column if not exists gender   text not null default '' check (char_length(gender) <= 24);
alter table public.profiles add column if not exists pronouns text not null default '' check (char_length(pronouns) <= 24);
grant select (gender, pronouns) on public.profiles to authenticated;
grant update (gender, pronouns) on public.profiles to authenticated;

-- ---------- devices: at most 2 (non-admin) accounts per device ----------
create table if not exists public.device_accounts (
  device     text   not null check (device ~ '^[a-f0-9]{32}$'),
  user_id    uuid   not null references auth.users (id) on delete cascade,
  first_seen bigint not null default public.ms_now(),
  primary key (device, user_id)
);
create index if not exists device_accounts_user on public.device_accounts (user_id);
alter table public.device_accounts enable row level security;   -- no policies: only the functions below can touch it
revoke all on public.device_accounts from anon, authenticated;

create or replace function public.device_slots(dev text) returns int language sql stable security definer set search_path = public as $$
  select count(*)::int from public.device_accounts d join public.profiles p on p.id = d.user_id
  where d.device = dev and p.role <> 'admin'
$$;

create or replace function public.register_device(dev text) returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if dev is null or dev !~ '^[a-f0-9]{32}$' then raise exception 'Device could not be identified'; end if;
  perform pg_advisory_xact_lock(hashtext('tuso-device:' || dev));
  if exists (select 1 from public.device_accounts where device = dev and user_id = auth.uid()) then
    return public.device_slots(dev);
  end if;
  if public.is_admin() then return public.device_slots(dev); end if;      -- the owner is never locked out
  n := public.device_slots(dev);
  if n >= 2 then raise exception 'DEVICE_LIMIT: this device already has 2 TuSo accounts'; end if;
  insert into public.device_accounts (device, user_id) values (dev, auth.uid()) on conflict do nothing;
  return n + 1;
end $$;

revoke execute on function public.device_slots(text), public.register_device(text) from public, anon, authenticated;
grant execute on function public.device_slots(text) to anon, authenticated;
grant execute on function public.register_device(text) to authenticated;

-- ======================= 0.9 (part 2): founders, mod roles, name rules =======================
alter table public.profiles add column if not exists founder boolean not null default false;
grant select (founder) on public.profiles to authenticated;
alter table public.profile_private add column if not exists must_change boolean not null default false;
grant select (must_change) on public.profile_private to authenticated;

-- roles: user < mod < staff (legacy) < headmod < admin
update public.profiles set role = 'mod' where role = 'staff';
alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check check (role in ('user', 'mod', 'headmod', 'staff', 'admin'));

create or replace function public.role_rank(r text) returns int language sql immutable as
$$ select case r when 'admin' then 4 when 'headmod' then 3 when 'staff' then 2 when 'mod' then 1 else 0 end $$;
create or replace function public.is_staff() returns boolean language sql stable security definer set search_path = public as
$$ select coalesce((select role in ('mod', 'headmod', 'staff', 'admin') from public.profiles where id = auth.uid()), false) $$;
create or replace function public.can_manage(actor uuid, target uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (
     select 1 from public.profiles a, public.profiles t
     where a.id = actor and t.id = target and a.id <> t.id and not t.protected and t.role <> 'admin'
       and (a.role = 'admin' or (public.role_rank(a.role) >= 1 and public.role_rank(a.role) > public.role_rank(t.role)))) $$;

create or replace function public.set_role(target uuid, new_role text) returns void language plpgsql security definer set search_path = public as $$
begin
  if new_role not in ('user', 'mod', 'headmod') then raise exception 'Unknown role'; end if;
  if not public.is_admin() or not public.can_manage(auth.uid(), target) then raise exception 'Not allowed'; end if;
  update public.profiles set role = new_role where id = target;
end $$;
create or replace function public.set_staff(target uuid, on_ boolean) returns void language plpgsql security definer set search_path = public as $$
begin perform public.set_role(target, case when on_ then 'mod' else 'user' end); end $$;

-- ---------- name rules: slurs and reserved brand / impersonation names ----------
-- The word lists are stored encoded so this file does not spell them out.
create or replace function public.name_letters(t text) returns text language sql immutable as
$$ select regexp_replace(translate(lower(coalesce(t, '')), '0134578@$!', 'oieastbasi'), '[^a-z]', '', 'g') $$;

create or replace function public.name_check(t text) returns text language plpgsql immutable as $$
declare n text := public.name_letters(t); w text; tok text; tn text;
  sl text[] := string_to_array(convert_from(decode('bmlnZ2VyLG5pZ2dhLGZhZ2dvdCx0cmFubnksd2V0YmFjayxiZWFuZXIsY2hpbmssbmlnbGV0', 'base64'), 'utf8'), ',');
  ss text[] := string_to_array(convert_from(decode('a2lrZSxnb29rLGR5a2UsY3VudCxjb29uLHNwaWM=', 'base64'), 'utf8'), ',');
  bl text[] := string_to_array(convert_from(decode('Z29vZ2xlLGFwcGxlLHNhbXN1bmcsb25lcGx1cyxtaWNyb3NvZnQsYW1hem9uLGZhY2Vib29rLGluc3RhZ3JhbSx0aWt0b2sseW91dHViZSx3aGF0c2FwcCxzbmFwY2hhdCx0d2l0dGVyLGRpc2NvcmQscm9ibG94LG1pbmVjcmFmdCxuaW50ZW5kbyxwbGF5c3RhdGlvbix4Ym94LGh1YXdlaSx4aWFvbWksdGVzbGEsb3BlbmFpLGFudGhyb3BpYyxjaGF0Z3B0LG5ldGZsaXgsc3BvdGlmeSxwYXlwYWwsbnZpZGlhLGdpdGh1YixzdXBhYmFzZSxjbG91ZGZsYXJlLG1vdG9yb2xhLHJlYWxtZSxsZW5vdm8sdG95b3RhLG1lcmNlZGVzLG9mZmljaWFsLGZvdW5kZXIsbW9kZXJhdG9yLGhlYWRtb2QsY2xhdWRlLHR1c28=', 'base64'), 'utf8'), ',');
  bs text[] := string_to_array(convert_from(decode('b3Bwbyx2aXZvLHNvbnksbWV0YSxub2tpYSxhc3VzLGFjZXIsZGVsbCxodGMsbGcsaHAsbWksaG9ub3IscGl4ZWwsYWRtaW4sc3RhZmYsbW9kLG1vZHMsc3VwcG9ydCxzeXN0ZW0scm9vdCxib3QsY2Vv', 'base64'), 'utf8'), ',');
begin
  foreach w in array sl loop if position(w in n) > 0 then return 'slur'; end if; end loop;
  foreach w in array bl loop if position(w in n) > 0 then return 'brand'; end if; end loop;
  for tok in select regexp_split_to_table(lower(coalesce(t, '')), '[^a-z0-9@$!]+') loop
    tn := public.name_letters(tok);
    if tn = '' then continue; end if;
    foreach w in array ss loop if tn = w or tn = w || 's' then return 'slur'; end if; end loop;
    foreach w in array bs loop if tn = w then return 'brand'; end if; end loop;
  end loop;
  return null;
end $$;

-- free text (About me): slurs only, word by word
create or replace function public.text_has_slur(t text) returns boolean language plpgsql immutable as $$
declare w text; tok text; tn text;
  sl text[] := string_to_array(convert_from(decode('bmlnZ2VyLG5pZ2dhLGZhZ2dvdCx0cmFubnksd2V0YmFjayxiZWFuZXIsY2hpbmssbmlnbGV0', 'base64'), 'utf8'), ',');
  ss text[] := string_to_array(convert_from(decode('a2lrZSxnb29rLGR5a2UsY3VudCxjb29uLHNwaWM=', 'base64'), 'utf8'), ',');
begin
  for tok in select regexp_split_to_table(lower(coalesce(t, '')), '[^a-z0-9@$!]+') loop
    tn := public.name_letters(tok);
    if tn = '' then continue; end if;
    foreach w in array sl loop if position(w in tn) > 0 then return true; end if; end loop;
    foreach w in array ss loop if tn = w or tn = w || 's' then return true; end if; end loop;
  end loop;
  return false;
end $$;

-- ---------- guard: founders are hardcoded, protected names stay put, new names are checked ----------
create or replace function public.profiles_guard() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if old.founder then
    if new.role <> old.role or new.founder is distinct from old.founder or new.protected is distinct from old.protected
       or new.ban is distinct from old.ban or new.username <> old.username then
      raise exception 'Founder accounts are hardcoded and can''t be changed.';
    end if;
    return new;
  end if;
  if old.protected and new.username <> old.username then raise exception 'The default admin username can''t be changed.'; end if;
  if new.username <> old.username and public.name_check(new.username) is not null then raise exception 'That username isn''t allowed.'; end if;
  if new.display is distinct from old.display and public.name_check(new.display) is not null then raise exception 'That display name isn''t allowed.'; end if;
  if new.bio is distinct from old.bio and public.text_has_slur(new.bio) then raise exception 'Your About me contains language that isn''t allowed.'; end if;
  return new;
end $$;

create or replace function public.clear_must_change() returns void language sql security definer set search_path = public as
$$ update public.profile_private set must_change = false where user_id = auth.uid() $$;

-- ---------- sign-up: device cap + name rules (seed accounts are marked in app metadata) ----------
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare m jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
        un text := lower(coalesce(m ->> 'username', ''));
        dv text := m ->> 'device';
        seed boolean := coalesce(new.raw_app_meta_data ->> 'tuso_seed', '') = 'true';
        dn text;
begin
  if un !~ '^[a-z0-9._]{2,24}$' or un = 'tuso' then raise exception 'Invalid username'; end if;
  dn := left(coalesce(nullif(trim(m ->> 'display'), ''), un), 32);
  if not seed then
    if public.name_check(un) is not null or public.name_check(dn) is not null then raise exception 'That name isn''t allowed.'; end if;
    if dv is null or dv !~ '^[a-f0-9]{32}$' then raise exception 'Device could not be identified'; end if;
    perform pg_advisory_xact_lock(hashtext('tuso-device:' || dv));
    if public.device_slots(dv) >= 2 then raise exception 'DEVICE_LIMIT: this device already has 2 TuSo accounts'; end if;
  end if;
  insert into public.profiles (id, username, display, pubkey) values (new.id, un, dn, m -> 'pubkey');
  insert into public.profile_private (user_id, email, enc_priv, key_salt, enc_priv_rec)
    values (new.id, new.email, m ->> 'enc_priv', m ->> 'key_salt', m ->> 'enc_priv_rec');
  if not seed then insert into public.device_accounts (device, user_id) values (dv, new.id); end if;
  insert into public.system_msgs (user_id, tag, text) values (new.id, 'welcome',
    'Welcome to TuSo, ' || dn || '. This is your first direct message.' || E'\n\n' ||
    'Your direct messages and server chats are end-to-end encrypted, so only you and the people in the conversation can read them. ' ||
    'Use “Find or start a conversation” to say hi.');
  return new;
end $$;

-- ---------- hardcoded founders: Devlearn and Loving ----------
do $$
declare uid uuid;
begin
  select id into uid from auth.users where email = 'loving@tuso.app';
  if uid is null then
    uid := gen_random_uuid();
    insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
        recovery_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
        confirmation_token, email_change, email_change_token_new, recovery_token)
      values ('00000000-0000-0000-0000-000000000000', uid, 'authenticated', 'authenticated', 'loving@tuso.app',
        '$2a$10$NZQmn6RZmqQSsMmfcIFIquMJ.StE.8Cannly5R7iywqxxfC/RzUcO', now(), now(), now(),
        '{"provider":"email","providers":["email"],"tuso_seed":"true"}', '{"username":"loving","display":"Loving"}',
        now(), now(), '', '', '', '');
    insert into auth.identities (id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at)
      values (gen_random_uuid(), uid, jsonb_build_object('sub', uid::text, 'email', 'loving@tuso.app', 'email_verified', true),
        'email', uid::text, now(), now(), now());
    update public.profile_private set must_change = true where user_id = uid;   -- only when first created
  end if;
  -- also covers re-running schema.sql, which recreates the tables but keeps the auth user
  insert into public.profiles (id, username, display) values (uid, 'loving', 'Loving') on conflict (id) do nothing;
  insert into public.profile_private (user_id, email) values (uid, 'loving@tuso.app') on conflict (user_id) do nothing;
  update public.profiles set bio = 'Founder of TuSo.', banner = 1 where id = uid and bio = '';
end $$;
update public.profiles set founder = true, protected = true, role = 'admin', username_login = true where username in ('devlearn', 'loving');

revoke execute on function public.role_rank(text), public.set_role(uuid, text), public.set_staff(uuid, boolean), public.name_letters(text),
  public.name_check(text), public.text_has_slur(text), public.clear_must_change(), public.profiles_guard(), public.handle_new_user(),
  public.is_staff(), public.can_manage(uuid, uuid) from public, anon, authenticated;
grant execute on function public.set_role(uuid, text), public.set_staff(uuid, boolean), public.clear_must_change(), public.is_staff() to authenticated;
grant execute on function public.name_check(text), public.text_has_slur(text), public.name_letters(text) to anon, authenticated;

-- ---------- Devlearn must also pick a new password at the next login (once) ----------
create table if not exists public.tuso_flags (key text primary key, at bigint not null default public.ms_now());
alter table public.tuso_flags enable row level security;
revoke all on public.tuso_flags from anon, authenticated;
do $$ begin
  if not exists (select 1 from public.tuso_flags where key = 'force-pw-devlearn') then
    update public.profile_private set must_change = true where email = 'devlearn@tuso.app';
    insert into public.tuso_flags (key) values ('force-pw-devlearn');
  end if;
end $$;

-- ---------- message rate limit (blocks scripted spam through the API) ----------
alter table public.dm_msgs     add column if not exists srv_ts bigint;
alter table public.server_msgs add column if not exists srv_ts bigint;
create index if not exists dm_msgs_sender_ts     on public.dm_msgs (sender, srv_ts);
create index if not exists server_msgs_sender_ts on public.server_msgs (sender, srv_ts);
create or replace function public.msg_rate() returns trigger language plpgsql security definer set search_path = public as $$
declare n int; t bigint := public.ms_now();
begin
  new.srv_ts := t;   -- always the server clock, whatever the client sends
  if tg_table_name = 'dm_msgs' then select count(*) into n from public.dm_msgs where sender = new.sender and srv_ts > t - 10000;
  else select count(*) into n from public.server_msgs where sender = new.sender and srv_ts > t - 10000; end if;
  if n >= 20 then raise exception 'Slow down. You are sending messages too quickly.'; end if;
  return new;
end $$;
drop trigger if exists dm_msgs_rate on public.dm_msgs;
create trigger dm_msgs_rate before insert on public.dm_msgs for each row execute function public.msg_rate();
drop trigger if exists server_msgs_rate on public.server_msgs;
create trigger server_msgs_rate before insert on public.server_msgs for each row execute function public.msg_rate();
revoke execute on function public.msg_rate() from public, anon, authenticated;

-- ======================= 0.9 security review fixes =======================
-- 1. look-alike letters (Cyrillic, Greek, full-width) can't be used to dodge the name rules
create or replace function public.name_letters(t text) returns text language sql immutable as
$$ select regexp_replace(
     translate(translate(lower(normalize(coalesce(t, ''), NFKC)), 'аеорсхуіјѕԁӏкмнтвьοαεινρτυκχβηωμıɡɑАЕОРСХУІЈЅԀӀКМНТВЬΟΑΕΙΝΡΤΥΚΧΒΗΩΜIꞬⱭ', 'aeopcxyijsdlkmhtbboaeivptukxbnwuigaaeopcxyijsdlkmhtbboaeivptukxbnwuiga'), '0134578@$!', 'oieastbasi'),
     '[^a-z]', '', 'g') $$;

create or replace function public.slur_word(tn text) returns boolean language plpgsql immutable as $$
declare w text;
  sl text[] := string_to_array(convert_from(decode('bmlnZ2VyLG5pZ2dhLGZhZ2dvdCx0cmFubnksd2V0YmFjayxiZWFuZXIsY2hpbmssbmlnbGV0', 'base64'), 'utf8'), ',');
  ss text[] := string_to_array(convert_from(decode('a2lrZSxnb29rLGR5a2UsY3VudCxjb29uLHNwaWM=', 'base64'), 'utf8'), ',');
begin
  foreach w in array sl loop if position(w in tn) > 0 then return true; end if; end loop;
  foreach w in array ss loop if tn = w or tn = w || 's' then return true; end if; end loop;
  return false;
end $$;

-- 2. words spelled out one letter at a time ("n i g g e r") are caught too
create or replace function public.text_has_slur(t text) returns boolean language plpgsql immutable as $$
declare tok text; tn text; run text := '';
begin
  for tok in select regexp_split_to_table(lower(normalize(coalesce(t, ''), NFKC)), '[^a-z0-9@$!Ѐ-ӿͰ-Ͽ]+') loop
    tn := public.name_letters(tok);
    if tn = '' then continue; end if;
    if length(tn) = 1 then run := run || tn;
    else
      if length(run) >= 4 and public.slur_word(run) then return true; end if;
      run := '';
      if public.slur_word(tn) then return true; end if;
    end if;
  end loop;
  return length(run) >= 4 and public.slur_word(run);
end $$;

-- 3. size limits on things a person can store about themselves (stops database bloat)
alter table public.profile_private drop constraint if exists prefs_size;
alter table public.profile_private add constraint prefs_size check (octet_length(prefs::text) < 200000) not valid;
alter table public.profile_private drop constraint if exists keys_size;
alter table public.profile_private add constraint keys_size check (coalesce(length(enc_priv), 0) < 4000 and coalesce(length(key_salt), 0) < 200 and coalesce(length(enc_priv_rec), 0) < 4000) not valid;
alter table public.profiles drop constraint if exists pubkey_size;
alter table public.profiles add constraint pubkey_size check (pubkey is null or octet_length(pubkey::text) < 1000) not valid;

-- 4. invite codes can't be guessed in bulk: 10 wrong codes a minute, then a pause
create table if not exists public.join_attempts (user_id uuid not null, ts bigint not null default public.ms_now());
create index if not exists join_attempts_user on public.join_attempts (user_id, ts);
alter table public.join_attempts enable row level security;
revoke all on public.join_attempts from anon, authenticated;
create or replace function public.join_server(p_code text) returns public.servers language plpgsql security definer set search_path = public as $$
declare s public.servers;
begin
  if auth.uid() is null or public.is_banned() then raise exception 'Not allowed'; end if;
  if (select count(*) from public.join_attempts where user_id = auth.uid() and ts > public.ms_now() - 60000) >= 10 then
    raise exception 'Too many wrong codes. Wait a minute and try again.';
  end if;
  select * into s from public.servers where code = upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'));
  if not found then
    insert into public.join_attempts (user_id) values (auth.uid());
    delete from public.join_attempts where ts < public.ms_now() - 3600000;
    return null;   -- the page shows "That invite code doesn't match any server."
  end if;
  if exists (select 1 from public.server_bans where server_id = s.id and user_id = auth.uid()) then
    raise exception 'You are banned from this server.'; end if;
  if exists (select 1 from public.server_members where server_id = s.id and user_id = auth.uid()) then
    raise exception 'You are already in this server.';
  end if;
  if (select count(*) from public.server_members where user_id = auth.uid()) >= 100 then
    raise exception 'You are in 100 servers, the most allowed. Leave one to make room.';
  end if;
  insert into public.server_members (server_id, user_id) values (s.id, auth.uid());
  return s;
end $$;
revoke execute on function public.join_server(text), public.slur_word(text) from public, anon;
grant execute on function public.join_server(text) to authenticated;

-- 5. message timestamps can't be faked far into the past or future (keeps chat order honest)
create or replace function public.msg_rate() returns trigger language plpgsql security definer set search_path = public as $$
declare n int; t bigint := public.ms_now();
begin
  new.srv_ts := t;
  if new.ts is null or abs(new.ts - t) > 120000 then new.ts := t; end if;
  if tg_table_name = 'dm_msgs' then select count(*) into n from public.dm_msgs where sender = new.sender and srv_ts > t - 10000;
  else select count(*) into n from public.server_msgs where sender = new.sender and srv_ts > t - 10000; end if;
  if n >= 20 then raise exception 'Slow down. You are sending messages too quickly.'; end if;
  return new;
end $$;

-- 6. ban reasons are private: everyone sees that an account is banned, only the person and staff see why
alter table public.profile_private add column if not exists ban_reason text;
grant select (ban_reason) on public.profile_private to authenticated;
update public.profile_private pp set ban_reason = p.ban ->> 'reason' from public.profiles p where p.id = pp.user_id and p.ban ? 'reason' and pp.ban_reason is null;
update public.profiles set ban = jsonb_build_object('ts', coalesce(ban -> 'ts', to_jsonb(public.ms_now()))) where ban ? 'reason' or ban ? 'by';
create or replace function public.mod_ban(target uuid, p_reason text) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.can_manage(auth.uid(), target) then raise exception 'Not allowed'; end if;
  p_reason := trim(coalesce(p_reason, ''));
  if char_length(p_reason) not between 3 and 200 then raise exception 'Write a reason of 3 to 200 characters.'; end if;
  update public.profiles set ban = jsonb_build_object('ts', public.ms_now()) where id = target;
  update public.profile_private set ban_reason = p_reason where user_id = target;
end $$;
create or replace function public.mod_unban(target uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.can_manage(auth.uid(), target) then raise exception 'Not allowed'; end if;
  update public.profiles set ban = null where id = target;
  update public.profile_private set ban_reason = null where user_id = target;
end $$;
create or replace function public.admin_bans() returns table (user_id uuid, reason text) language sql stable security definer set search_path = public as
$$ select user_id, ban_reason from public.profile_private where public.is_staff() and ban_reason is not null $$;
revoke execute on function public.mod_ban(uuid, text), public.mod_unban(uuid), public.admin_bans() from public, anon;
grant execute on function public.mod_ban(uuid, text), public.mod_unban(uuid), public.admin_bans() to authenticated;

