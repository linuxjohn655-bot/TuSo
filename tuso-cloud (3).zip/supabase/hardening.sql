-- TuSo hardening for Supabase. Safe to run any number of times; it never deletes data.
-- Run it in Supabase -> SQL Editor after schema.sql / upgrade-0.9.sql.
--
-- Why: the Supabase "publishable" key sits in the web page, so anyone can call your project's API with it.
-- That is normal and cannot be hidden. What protects you is that the database says no. This script makes
-- sure the "no" is as tight as possible and that scripted abuse is slowed down.

-- 1. Tables in public are never open to the anonymous (logged-out) role, and new objects are closed by default.
revoke all on all tables    in schema public from anon;
revoke all on all sequences in schema public from anon;
do $$ declare r text; begin
  foreach r in array array['postgres', 'supabase_admin'] loop
    begin
      execute format('alter default privileges for role %I in schema public revoke all on tables from anon, authenticated', r);
      execute format('alter default privileges for role %I in schema public revoke all on sequences from anon, authenticated', r);
      execute format('alter default privileges for role %I in schema public revoke execute on functions from anon, authenticated, public', r);
    exception when others then null; end;
  end loop;
end $$;

-- 2. Row level security is on for every table.
do $$ declare r record; begin
  for r in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', r.tablename);
  end loop;
end $$;

-- 3. Functions: nothing is callable by "everyone". Logged-out visitors get only the few harmless helpers
--    the login and sign-up screens need.
revoke execute on all functions in schema public from public;
do $$ declare r record; begin
  for r in select p.oid::regprocedure as sig, p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.prokind = 'f' loop
    if r.proname in ('username_free', 'login_email', 'device_slots', 'name_check', 'text_has_slur', 'name_letters') then
      execute format('grant execute on function %s to anon, authenticated', r.sig);
    else
      execute format('revoke execute on function %s from anon', r.sig);
    end if;
  end loop;
end $$;

-- 4. Time and size limits per request (stops expensive scripted queries).
alter role anon set statement_timeout = '5s';
alter role authenticated set statement_timeout = '20s';
do $$ begin alter role authenticator set pgrst.db_max_rows = '1000'; exception when others then null; end $$;
do $$ begin perform pg_notify('pgrst', 'reload config'); exception when others then null; end $$;

-- 5. The GraphQL endpoint is not used by TuSo. Close it.
do $$ begin
  if exists (select 1 from pg_namespace where nspname = 'graphql_public') then
    revoke usage on schema graphql_public from anon, authenticated;
  end if;
exception when others then null; end $$;
