// Builds the deployable site into ./dist: minified, hashed, cache-friendly, with strict security headers.
// Vercel runs this for you (vercel.json). You can also run it yourself: npm install && npm run build
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { transform } from 'esbuild';
import { minify as minifyHtml } from 'html-minifier-terser';

const root = path.dirname(new URL(import.meta.url).pathname);
const out = path.join(root, 'dist');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(path.join(out, 'assets'), { recursive: true });

const SUPABASE = (fs.readFileSync(path.join(root, 'index.html'), 'utf8').match(/url:\s*'(https:\/\/[^']+\.supabase\.co)'/) || [])[1];
if (!SUPABASE) throw new Error('Could not find the Supabase URL in index.html');

const hash = (buf) => crypto.createHash('sha256').update(buf).digest('hex').slice(0, 10);
const emit = (name, ext, data) => {
  const file = `assets/${name}.${hash(data)}.${ext}`;
  fs.writeFileSync(path.join(out, file), data);
  return '/' + file;
};

let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

// 1. inline <style> and <script> move to their own cacheable files
const css = html.match(/<style>([\s\S]*?)<\/style>/);
const js = html.match(/<script>([\s\S]*?)<\/script>/);
if (!css || !js) throw new Error('Expected one inline <style> and one inline <script>');
const cssMin = (await transform(css[1], { loader: 'css', minify: true, legalComments: 'none' })).code;
const jsMin = `(function(){var l=document.getElementById('fontcss');if(l)l.media='all'})();` +
  (await transform(js[1], { loader: 'js', minify: true, target: 'es2020', legalComments: 'none' })).code;   // the first line un-blocks the font stylesheet
const cssUrl = emit('app', 'css', cssMin);
const jsUrl = emit('app', 'js', jsMin);
const sbUrl = emit('supabase', 'js', fs.readFileSync(path.join(root, 'vendor/supabase.js')));
const argonUrl = emit('argon2', 'js', fs.readFileSync(path.join(root, 'vendor/argon2.js')));

html = html.replace(css[0], `<link rel="stylesheet" href="${cssUrl}">`);
html = html.replace(/<script src="vendor\/supabase\.js"><\/script>\s*<script src="vendor\/argon2\.js"><\/script>\s*<script>[\s\S]*?<\/script>/,
  `<script defer src="${sbUrl}"></script><script defer src="${argonUrl}"></script><script defer src="${jsUrl}"></script>`);
// the font stylesheet is loaded without blocking the first paint; no inline handler (the CSP forbids those)
html = html.replace(` media="print" onload="this.media='all'"`, ` media="print" id="fontcss"`);

html = await minifyHtml(html, { collapseWhitespace: true, conservativeCollapse: true, removeComments: true, minifyCSS: false, minifyJS: false });
fs.writeFileSync(path.join(out, 'index.html'), html);

// 2. headers
const CSP = [
  "default-src 'self'",
  "script-src 'self' 'wasm-unsafe-eval'",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src https://fonts.gstatic.com",
  "img-src 'self' data: blob:",
  "media-src 'self' data: blob:",
  `connect-src 'self' ${SUPABASE} ${SUPABASE.replace('https://', 'wss://')} https://api.pwnedpasswords.com`,
  "worker-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'self'",
  "frame-ancestors 'none'",
  'upgrade-insecure-requests',
].join('; ');
const security = [
  { key: 'Content-Security-Policy', value: CSP },
  { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' },
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'Referrer-Policy', value: 'no-referrer' },
  { key: 'Cross-Origin-Opener-Policy', value: 'same-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=(), payment=(), usb=(), interest-cohort=()' },
];
const vercel = {
  cleanUrls: true,
  headers: [
    { source: '/assets/(.*)', headers: [...security, { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] },
    { source: '/(.*)', headers: [...security, { key: 'Cache-Control', value: 'public, max-age=0, must-revalidate' }] },
  ],
};
// Vercel reads headers from vercel.json at the project root. A copy sits in dist too, for drag-and-drop uploads of dist.
const rootCfg = JSON.parse(fs.readFileSync(path.join(root, 'vercel.json'), 'utf8'));
fs.writeFileSync(path.join(root, 'vercel.json'), JSON.stringify({ ...rootCfg, headers: vercel.headers }, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'vercel.json'), JSON.stringify(vercel, null, 2) + '\n');
fs.writeFileSync(path.join(out, 'robots.txt'), 'User-agent: *\nDisallow: /\n');

const size = (f) => fs.statSync(path.join(out, f)).size;
console.log('built dist/:');
for (const f of [jsUrl, cssUrl, sbUrl, argonUrl, '/index.html'].map((x) => x.replace(/^\//, ''))) console.log('  ' + f.padEnd(34) + (size(f) / 1024).toFixed(1) + ' KB');
