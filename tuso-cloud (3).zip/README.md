# TuSo (cloud edition)

Standalone TuSo site. Accounts, servers, messages, bug reports and moderation live in your Supabase project.
Direct messages and server chats are end-to-end encrypted in the browser (WebCrypto), so Supabase only stores ciphertext.

## Set up (5 minutes)

1. **Run the database script.** Supabase dashboard → SQL Editor → New query → paste `supabase/schema.sql` → Run.
   ⚠️ `schema.sql` starts from a clean slate and **deletes all TuSo data** when run again. Already running TuSo and just adding a feature? Run only the small add-on file (for example `supabase/roles.sql`), which never deletes anything.
2. **Turn off email confirmation.** Authentication → Sign In / Providers → Email → switch **Confirm email** off. (TuSo logs people in right after sign-up so it can create their encryption key.)
3. **Check Realtime (optional).** The script adds the chat tables to the `supabase_realtime` publication. If it printed a notice that it couldn't, TuSo still works; it just updates every 6 seconds.
4. **Put the site online.** Follow "Deploy on Vercel" below. The site must be served over **https** (or `localhost`) because encryption needs a secure page.
5. **Run `supabase/hardening.sql`** once in the SQL Editor (see "Locking down the API").
   To test locally: `npx serve .` then open the printed address.
5. **First admin login.** Username `Devlearn`, then the password you chose. The first login creates the admin's encryption key and shows a **recovery key**. Save it. Then change the password in Settings → My account.

The project URL and publishable key are already in `index.html` (`CFG` near the top of the script). The publishable key is meant to be public; row level security protects the data. Never put a service-role or secret key in this site.

## How the encryption works

- Each account has an ECDH P-256 key pair made in the browser. The private key is stored wrapped by your password (PBKDF2, 300k rounds, AES-GCM) and again by your recovery key.
- Direct messages use a key derived from both people's keys. Server chats use one random key per server, handed to each member wrapped for them. A new member sees a lock until an existing member opens TuSo and passes the key on.
- Safety numbers (Settings → My account, and at the top of each DM) let two people confirm nobody swapped keys.

## Know the limits

- **Forget your password and lose the recovery key** → old messages can't be read. "Reset encryption" makes a new key but old messages stay unreadable.
- Not encrypted: usernames, display names, bios, avatars, bug reports, server names, and messages from the TuSo bot.
- Admins can ban, warn, delete accounts and servers, but cannot read anyone's messages.
- A server with no one online who holds the key leaves new joiners locked until someone opens TuSo.
- Email changes aren't supported yet (the field is read-only).

## Server roles (v0.8)

Owners, and members given the right permissions, can open **Roles and members** in a server's side panel: create roles with colours and permissions, drag them into rank order, give or take roles for many members at once, and kick or ban. Higher roles outrank lower ones; nobody can touch someone at or above their own rank, and the owner is above everyone.
Existing installs: run `supabase/roles.sql` once in the SQL Editor. Until then TuSo works as before, without roles.

## Version 0.9: what to run

**Already running TuSo?** Open Supabase, SQL Editor, paste `supabase/upgrade-0.9.sql` and run it. It never deletes data and is safe to run twice. Then upload the new `index.html` and the whole `vendor/` folder (it now has `argon2.js`). Until you run it, TuSo keeps working, but the new features stay off.

**New install:** `schema.sql` already includes everything.

What 0.9 adds:

- **Profile view.** Tap your own card (bottom left), or anyone's picture or name in chat, to see name, about, gender, pronouns, member since and safety number.
- **Two accounts per device.** The browser keeps a random device id. A device can hold 2 accounts; a third cannot sign up or log in there. Deleting an account frees its slot. Founders do not count.
- **Roles on people:** Mod, Head Mod, Founder badges. Founders (Devlearn and Loving) are hardcoded in the database: their role, ban state and username cannot be changed, not even by another admin. Only a Founder can give Mod or Head Mod (Settings, Admin). A Head Mod can warn and ban Mods; a Mod can warn and ban members.
- **Loving account.** Username `loving`, starter password `82222222`. It has to be changed at first login. **Log in as Loving straight away after running the SQL:** an 8 digit password is guessable, and its hash is in the SQL file.
- **Name rules.** Slurs and reserved names (company and brand names such as Google, Apple, Samsung, OnePlus, plus words like official, founder, moderator) are refused for new usernames and display names. Existing accounts that have one are asked to pick a new name at their next login. Slurs are also blocked when sending a message and hidden when received.
- **Official messages** from TuSo are shown as cards (welcome, release, warning, bug report).
- **App PIN.** Settings, My account, App PIN: 4 or 6 digits, asked every time TuSo is opened on that device and after 2 minutes away. 5 wrong tries pause it (30 seconds, doubling), 10 log you out. It is a screen lock stored in this browser (hashed with Argon2id); it doesn't encrypt anything extra and doesn't replace your password. Logging in with your password doesn't ask for it.
- **Faster start.** Requests run in parallel, messages decrypt in batches, and the browser connects to Supabase and loads fonts without blocking the page.
- **Founders must change starter passwords.** Both Loving and Devlearn are asked for a new password at their next login (once).
- **Passwords.** Your encryption key is wrapped with Argon2id (64 MiB, 3 passes). Keys made before 0.9 are upgraded the next time you log in. New passwords need 8+ characters including 1 special character, can't be common, can't contain your username, are checked against known breaches (only the first 5 characters of a SHA-1 hash leave your browser) and show a strength meter. Logins slow down after 5 wrong tries.

**Do this too:** Supabase, Authentication, Sign In / Providers (or Policies), set *Minimum password length* to 8. The 8 character and special-character rules in the page can be bypassed by someone calling the API directly; this setting makes the server enforce it as well.

### Honest limits

- "Military grade" is a marketing phrase, not a standard. What is really here: AES-256-GCM, ECDH P-256, Argon2id, TLS, row level security. It is not audited, and there is no 2-factor login yet.
- Supabase Auth stores your login password with bcrypt on the server. Your messages' encryption key never leaves your browser unwrapped.
- The device limit is best effort. A device id lives in the browser, so clearing site data, private windows or another browser look like a new device. It stops casual account farming, not a determined person.
- The word filter catches common spellings and number swaps (like 3 for e). It can't catch everything, and it can't read messages on the server because they are encrypted; it runs in the app.

## Deploy on Vercel

The project is a static site (no server code); Supabase is the backend. `build.mjs` turns `index.html` + `vendor/` into `dist/`: minified, with content-hashed files cached for a year, scripts that don't block the first paint, and strict security headers (CSP, HSTS, no framing, no referrer, and more).

1. Put this folder in a GitHub repo and import it at vercel.com/new. Framework preset: **Other**. Vercel reads `vercel.json` (build command `node build.mjs`, output `dist`), so you don't need to change anything.
2. Or without GitHub: run `npm install && npm run build` here, then drag the `dist` folder onto vercel.com/new. `dist/vercel.json` carries the headers.
3. In Supabase, Authentication, URL Configuration: set **Site URL** to your Vercel address.
4. Add your domain in Vercel if you have one. Vercel gives https and Brotli compression automatically.

If you change the Supabase project, edit `CFG` in `index.html` and rebuild: the headers are generated from that URL.

## Locking down the API

Anyone can open your site, see the Supabase URL and publishable key, and call your project's API from a script. That is how Supabase is designed, and it cannot be hidden or limited to your website (browsers send an Origin header that other programs can fake). The protection is that the database refuses everything it should refuse. What TuSo does:

- Row level security on every table. Logged-out visitors can read **no** table and run only 6 harmless helper functions (checked by the test suite).
- Logged-in users can only read and write their own conversations, servers and profile. Messages are encrypted, so even the database holds only ciphertext.
- `supabase/hardening.sql` (run it once, it's safe to repeat) closes anything left open by default, sets a 5 second limit for logged-out queries and 20 seconds for users, caps rows per request, and turns off the unused GraphQL endpoint.
- Messages are limited to 20 per 10 seconds per person, enforced by the database with its own clock, so a script can't flood a chat. Bug reports were already rate limited.
- Accounts: 8+ character passwords with a special character, a name filter, 2 accounts per device and login slowdowns in the page.

Do these in the Supabase dashboard too:

- Authentication, Rate Limits: lower the sign-up and sign-in limits per hour. These are what stop scripted account creation.
- Authentication, Sign In / Providers: turn off **anonymous sign-ins** and any provider you don't use. Set minimum password length to 12.
- Never put the **secret** or **service_role** key in this site. Only the publishable key (it starts with `sb_publishable_`) belongs here.
- Optional later: CAPTCHA (Cloudflare Turnstile) on sign-up. It needs a small code change in the page first, so don't switch it on before that or sign-ups will fail.

## Something not working?

Settings → My account → **Connection check** runs safe tests against your backend and shows exactly what fails (and the database's error). Accounts made in the old browser-only demo are not moved to Supabase; sign up again on the live site.
