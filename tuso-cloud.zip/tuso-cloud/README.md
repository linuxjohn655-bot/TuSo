# TuSo (cloud edition)

Standalone TuSo site. Accounts, servers, messages, bug reports and moderation live in your Supabase project.
Direct messages and server chats are end-to-end encrypted in the browser (WebCrypto), so Supabase only stores ciphertext.

## Set up (5 minutes)

1. **Run the database script.** Supabase dashboard → SQL Editor → New query → paste `supabase/schema.sql` → Run.
   ⚠️ `schema.sql` starts from a clean slate and **deletes all TuSo data** when run again. Already running TuSo and just adding a feature? Run only the small add-on file (for example `supabase/roles.sql`), which never deletes anything.
2. **Turn off email confirmation.** Authentication → Sign In / Providers → Email → switch **Confirm email** off. (TuSo logs people in right after sign-up so it can create their encryption key.)
3. **Check Realtime (optional).** The script adds the chat tables to the `supabase_realtime` publication. If it printed a notice that it couldn't, TuSo still works; it just updates every 6 seconds.
4. **Put the site online.** Upload this folder (index.html + vendor/) to Vercel, Netlify, Cloudflare Pages or GitHub Pages. It must be served over **https** (or `localhost`) because encryption needs a secure page.
   To test locally: `npx serve .` then open the printed address.
5. **First admin login.** Username `Devlearn`, then the password you chose. The first login creates the admin's encryption key and shows a **recovery key**. Save it. Then change the password in Settings → My account.

The project URL and publishable key are already in `index.html` (`CFG` near the top of the script). The publishable key is meant to be public; row level security protects the data. Never put a service-role or secret key in this site.

## How the encryption works

- Each account has an ECDH P-256 key pair made in the browser. The private key is stored wrapped by your password (PBKDF2, 300k rounds, AES-GCM) and again by your recovery key.
- Direct messages use a key derived from both people's keys. Server chats use one random key per server, handed to each member wrapped for them. A new member sees a lock until an existing member opens TuSo and passes the key on.
- Safety numbers (Settings → My account, and at the top of each DM) let two people confirm nobody swapped keys.

## Know the limits

- **Forget your password and lose the recovery key** → old messages can't be read. "Reset encryption" makes a new key but old messages stay unreadable.
- Not encrypted: usernames, display names, bios, avatars, bug reports, server names, and messages from the TuSo bot.
- Admins can ban, warn, delete accounts and servers, but cannot read anyone's messages.
- A server with no one online who holds the key leaves new joiners locked until someone opens TuSo.
- Email changes aren't supported yet (the field is read-only).

## Server roles (v0.8)

Owners, and members given the right permissions, can open **Roles and members** in a server's side panel: create roles with colours and permissions, drag them into rank order, give or take roles for many members at once, and kick or ban. Higher roles outrank lower ones; nobody can touch someone at or above their own rank, and the owner is above everyone.
Existing installs: run `supabase/roles.sql` once in the SQL Editor. Until then TuSo works as before, without roles.

## Something not working?

Settings → My account → **Connection check** runs safe tests against your backend and shows exactly what fails (and the database's error). Accounts made in the old browser-only demo are not moved to Supabase; sign up again on the live site.
