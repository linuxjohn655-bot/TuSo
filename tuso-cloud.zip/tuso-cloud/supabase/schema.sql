-- =====================================================================
-- TuSo database. Paste this whole file into the Supabase SQL editor and run it once.
-- Safe to re-run: it drops and recreates TuSo's own objects (this deletes TuSo data).
-- Messages are end-to-end encrypted in the browser. The database only ever
-- stores ciphertext for DMs and server chats. Row Level Security is on for everything.
-- =====================================================================

-- ---------- clean slate (TuSo objects only) ----------
drop trigger if exists tuso_on_auth_user on auth.users;
drop table if exists public.server_bans, public.member_roles, public.server_roles cascade;
drop table if exists public.bugs, public.warnings, public.server_msgs, public.server_keys,
  public.server_members, public.servers, public.system_msgs, public.dm_state,
  public.dm_msgs, public.profile_private, public.profiles cascade;
drop function if exists public.handle_new_user() cascade;

-- ---------- helpers ----------
create or replace function public.ms_now() returns bigint
language sql stable as $$ select (extract(epoch from clock_timestamp()) * 1000)::bigint $$;

-- ---------- tables ----------
create table public.profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  username text not null,
  display text not null check (char_length(display) between 1 and 32),
  bio text not null default '' check (char_length(bio) <= 190),
  avatar text check (avatar is null or char_length(avatar) < 400000),
  banner int not null default 0 check (banner between 0 and 12),
  banner_img text check (banner_img is null or char_length(banner_img) < 500000),
  status text not null default 'online' check (status in ('online', 'idle', 'dnd', 'invisible')),
  seen bigint not null default 0,
  role text not null default 'user' check (role in ('user', 'staff', 'admin')),
  hunter boolean not null default false,
  ban jsonb,
  protected boolean not null default false,
  username_login boolean not null default false,
  pubkey jsonb,
  created bigint not null default public.ms_now(),
  constraint username_format check (username ~ '^[a-z0-9._]{2,24}$' and username <> 'tuso')
);
create unique index profiles_username_key on public.profiles (username);

-- Private to each account: email, settings, and the password-wrapped private key.
create table public.profile_private (
  user_id uuid primary key references public.profiles (id) on delete cascade,
  email text,
  prefs jsonb not null default '{}'::jsonb,
  enc_priv text,
  key_salt text,
  enc_priv_rec text
);

-- Direct messages. a < b so each pair has exactly one key. iv + ct are AES-GCM ciphertext.
create table public.dm_msgs (
  id uuid primary key,
  seq bigint generated always as identity,
  a uuid not null references public.profiles (id) on delete cascade,
  b uuid not null references public.profiles (id) on delete cascade,
  sender uuid not null references public.profiles (id) on delete cascade,
  iv text not null,
  ct text not null check (char_length(ct) < 20000),
  ts bigint not null default public.ms_now(),
  check (a < b and sender in (a, b))
);
create index dm_msgs_pair on public.dm_msgs (a, b, seq);
create index dm_msgs_b on public.dm_msgs (b);
create index dm_msgs_seq on public.dm_msgs (seq);

-- Per-account conversation state (read marker, closed, opened). 'tuso' is the official account.
create table public.dm_state (
  user_id uuid not null references public.profiles (id) on delete cascade,
  peer text not null,
  read_ts bigint not null default 0,
  open_ts bigint not null default 0,
  closed_ts bigint not null default 0,
  primary key (user_id, peer)
);

-- Messages from the official TuSo account. Written by the server, readable only by the recipient.
create table public.system_msgs (
  id uuid primary key default gen_random_uuid(),
  seq bigint generated always as identity,
  user_id uuid not null references public.profiles (id) on delete cascade,
  tag text,
  text text not null check (char_length(text) < 4000),
  ts bigint not null default public.ms_now()
);
create unique index system_msgs_tag on public.system_msgs (user_id, tag) where tag is not null;
create index system_msgs_user on public.system_msgs (user_id, seq);

create table public.servers (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 32),
  owner uuid not null references public.profiles (id),
  code text not null unique,
  created bigint not null default public.ms_now()
);
create table public.server_members (
  server_id uuid not null references public.servers (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  joined bigint not null default public.ms_now(),
  primary key (server_id, user_id)
);
create index server_members_user on public.server_members (user_id);

-- The server key, wrapped separately for every member (only that member can unwrap it).
create table public.server_keys (
  server_id uuid not null references public.servers (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  wrapper uuid not null references public.profiles (id) on delete cascade,
  iv text not null,
  ct text not null,
  primary key (server_id, user_id)
);
create table public.server_msgs (
  id uuid primary key,
  seq bigint generated always as identity,
  server_id uuid not null references public.servers (id) on delete cascade,
  sender uuid not null references public.profiles (id) on delete cascade,
  iv text not null,
  ct text not null check (char_length(ct) < 20000),
  ts bigint not null default public.ms_now()
);
create index server_msgs_srv on public.server_msgs (server_id, seq);
create index server_msgs_seq on public.server_msgs (seq);

create table public.warnings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles (id) on delete cascade,
  issued_by uuid references public.profiles (id) on delete set null,
  reason text not null,
  ts bigint not null default public.ms_now(),
  ack boolean not null default false
);
create index warnings_user on public.warnings (user_id);

create table public.bugs (
  id uuid primary key,
  reporter uuid not null references public.profiles (id) on delete cascade,
  ts bigint not null default public.ms_now(),
  title text not null check (char_length(title) between 3 and 80),
  reason text not null check (char_length(reason) between 10 and 600),
  steps text not null check (char_length(steps) between 5 and 600),
  shots jsonb not null default '[]'::jsonb check (jsonb_typeof(shots) = 'array' and jsonb_array_length(shots) <= 5 and pg_column_size(shots) < 3000000),
  status text not null default 'open' check (status in ('open', 'checking', 'fixed', 'nobug')),
  prev text,
  handler uuid references public.profiles (id) on delete set null,
  upd bigint
);
create index bugs_reporter on public.bugs (reporter);

-- ---------- role helpers (security definer, so policies can use them without recursion) ----------
create or replace function public.is_staff() returns boolean language sql stable security definer set search_path = public as
$$ select coalesce((select role in ('staff', 'admin') from public.profiles where id = auth.uid()), false) $$;
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path = public as
$$ select coalesce((select role = 'admin' from public.profiles where id = auth.uid()), false) $$;
create or replace function public.is_banned() returns boolean language sql stable security definer set search_path = public as
$$ select coalesce((select ban is not null from public.profiles where id = auth.uid()), false) $$;
create or replace function public.is_member(sid uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from public.server_members where server_id = sid and user_id = auth.uid()) $$;
create or replace function public.can_manage(actor uuid, target uuid) returns boolean language sql stable security definer set search_path = public as
$$ select exists (
     select 1 from public.profiles a, public.profiles t
     where a.id = actor and t.id = target and a.id <> t.id and not t.protected and t.role <> 'admin'
       and (a.role = 'admin' or (a.role = 'staff' and t.role = 'user'))) $$;

-- ---------- new account: create profile, private row and welcome message ----------
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
declare m jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
        un text := lower(coalesce(m ->> 'username', ''));
        dn text;
begin
  if un !~ '^[a-z0-9._]{2,24}$' or un = 'tuso' then raise exception 'Invalid username'; end if;
  dn := left(coalesce(nullif(trim(m ->> 'display'), ''), un), 32);
  insert into public.profiles (id, username, display, pubkey) values (new.id, un, dn, m -> 'pubkey');
  insert into public.profile_private (user_id, email, enc_priv, key_salt, enc_priv_rec)
    values (new.id, new.email, m ->> 'enc_priv', m ->> 'key_salt', m ->> 'enc_priv_rec');
  insert into public.system_msgs (user_id, tag, text) values (new.id, 'welcome',
    'Welcome to TuSo, ' || dn || '. This is your first direct message.' || E'\n\n' ||
    'Your direct messages and server chats are end-to-end encrypted, so only you and the people in the conversation can read them. ' ||
    'Use “Find or start a conversation” to say hi.');
  return new;
end $$;
create trigger tuso_on_auth_user after insert on auth.users for each row execute function public.handle_new_user();

-- ---------- bug reports: at most 5 per hour per account ----------
create or replace function public.bugs_rate() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.bugs where reporter = new.reporter and ts > public.ms_now() - 3600000) >= 5 then
    raise exception 'You have sent 5 reports in the last hour. Try again later.';
  end if;
  return new;
end $$;
create trigger bugs_rate before insert on public.bugs for each row execute function public.bugs_rate();

create or replace function public.bugs_ack() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.system_msgs (user_id, text) values (new.reporter, 'Thanks for reporting “' || new.title || '”. Staff will take a look, and you will hear back here.');
  return new;
end $$;
create trigger bugs_ack after insert on public.bugs for each row execute function public.bugs_ack();

-- ---------- username changes: not for the protected admin ----------
create or replace function public.profiles_guard() returns trigger language plpgsql as $$
begin
  if old.protected and new.username <> old.username then raise exception 'The default admin username can''t be changed.'; end if;
  return new;
end $$;
create trigger profiles_guard before update on public.profiles for each row execute function public.profiles_guard();

-- ---------- row level security ----------
alter table public.profiles enable row level security;
alter table public.profile_private enable row level security;
alter table public.dm_msgs enable row level security;
alter table public.dm_state enable row level security;
alter table public.system_msgs enable row level security;
alter table public.servers enable row level security;
alter table public.server_members enable row level security;
alter table public.server_keys enable row level security;
alter table public.server_msgs enable row level security;
alter table public.warnings enable row level security;
alter table public.bugs enable row level security;

create policy profiles_read on public.profiles for select to authenticated using (true);
create policy profiles_update_own on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy private_read on public.profile_private for select to authenticated using (user_id = auth.uid());
create policy private_update on public.profile_private for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy dm_read on public.dm_msgs for select to authenticated using (auth.uid() in (a, b) and not public.is_banned());
create policy dm_insert on public.dm_msgs for insert to authenticated with check (sender = auth.uid() and auth.uid() in (a, b) and not public.is_banned());
create policy dm_delete on public.dm_msgs for delete to authenticated using (auth.uid() in (a, b) and not public.is_banned());

create policy state_all on public.dm_state for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy sys_read on public.system_msgs for select to authenticated using (user_id = auth.uid());
create policy sys_insert on public.system_msgs for insert to authenticated with check (user_id = auth.uid() and tag like 'release-%');

create policy srv_read on public.servers for select to authenticated using (public.is_member(id) or public.is_admin());
create policy mem_read on public.server_members for select to authenticated using (public.is_member(server_id) or public.is_admin());
create policy key_read on public.server_keys for select to authenticated using (public.is_member(server_id));
create policy key_delete on public.server_keys for delete to authenticated using (user_id = auth.uid());
create policy key_insert on public.server_keys for insert to authenticated with check (
  wrapper = auth.uid() and public.is_member(server_id)
  and exists (select 1 from public.server_members m where m.server_id = server_keys.server_id and m.user_id = server_keys.user_id));

create policy smsg_read on public.server_msgs for select to authenticated using (public.is_member(server_id) and not public.is_banned());
create policy smsg_insert on public.server_msgs for insert to authenticated with check (sender = auth.uid() and public.is_member(server_id) and not public.is_banned());
create policy smsg_delete on public.server_msgs for delete to authenticated using (sender = auth.uid());

create policy warn_read on public.warnings for select to authenticated using (user_id = auth.uid() or public.is_staff());
create policy warn_ack on public.warnings for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy bug_read on public.bugs for select to authenticated using (reporter = auth.uid() or public.is_staff());
create policy bug_insert on public.bugs for insert to authenticated with check (reporter = auth.uid() and status = 'open' and not public.is_banned());

-- ---------- table privileges (column level where it matters) ----------
revoke all on public.profiles, public.profile_private, public.dm_msgs, public.dm_state, public.system_msgs,
  public.servers, public.server_members, public.server_keys, public.server_msgs, public.warnings, public.bugs
  from anon, authenticated;

grant select (id, username, display, bio, avatar, banner, banner_img, status, seen, role, hunter, ban, protected, pubkey, created) on public.profiles to authenticated;
grant update (username, display, bio, avatar, banner, banner_img, status, seen, pubkey) on public.profiles to authenticated;
grant select (user_id, email, prefs, enc_priv, key_salt, enc_priv_rec) on public.profile_private to authenticated;
grant update (prefs, email, enc_priv, key_salt, enc_priv_rec) on public.profile_private to authenticated;
grant select, insert, delete on public.dm_msgs to authenticated;
grant select, insert, update, delete on public.dm_state to authenticated;
grant select, insert on public.system_msgs to authenticated;
grant select on public.servers, public.server_members to authenticated;
grant select, insert, delete on public.server_keys to authenticated;
grant select, insert, delete on public.server_msgs to authenticated;
grant select on public.warnings to authenticated;
grant update (ack) on public.warnings to authenticated;
grant select, insert on public.bugs to authenticated;

-- ---------- functions the app calls ----------
create or replace function public.username_free(u text) returns boolean language sql stable security definer set search_path = public as
$$ select lower(u) <> 'tuso' and not exists (select 1 from public.profiles where username = lower(u)) $$;

-- Only accounts flagged username_login (the default admin) can sign in by username. Everyone else uses their email.
create or replace function public.login_email(ident text) returns text language sql stable security definer set search_path = public as
$$ select pp.email from public.profiles p join public.profile_private pp on pp.user_id = p.id
   where p.username_login and p.username = lower(ident) $$;

create or replace function public.create_server(p_name text) returns public.servers language plpgsql security definer set search_path = public as $$
declare s public.servers; c text;
begin
  if auth.uid() is null or public.is_banned() then raise exception 'Not allowed'; end if;
  p_name := regexp_replace(trim(p_name), '\s+', ' ', 'g');
  if char_length(p_name) not between 2 and 32 then raise exception 'Use 2 to 32 characters.'; end if;
  if (select count(*) from public.server_members where user_id = auth.uid()) >= 100 then
    raise exception 'You are in 100 servers, the most allowed. Leave one to make room.';
  end if;
  loop
    c := upper(substr(md5(gen_random_uuid()::text), 1, 8));
    exit when not exists (select 1 from public.servers where code = c);
  end loop;
  insert into public.servers (name, owner, code) values (p_name, auth.uid(), c) returning * into s;
  insert into public.server_members (server_id, user_id) values (s.id, auth.uid());
  return s;
end $$;

create or replace function public.join_server(p_code text) returns public.servers language plpgsql security definer set search_path = public as $$
declare s public.servers;
begin
  if auth.uid() is null or public.is_banned() then raise exception 'Not allowed'; end if;
  select * into s from public.servers where code = upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'));
  if not found then raise exception 'That invite code doesn''t match any server.'; end if;
  if exists (select 1 from public.server_members where server_id = s.id and user_id = auth.uid()) then
    raise exception 'You are already in this server.';
  end if;
  if (select count(*) from public.server_members where user_id = auth.uid()) >= 100 then
    raise exception 'You are in 100 servers, the most allowed. Leave one to make room.';
  end if;
  insert into public.server_members (server_id, user_id) values (s.id, auth.uid());
  return s;
end $$;

create or replace function public.leave_server(p_id uuid) returns void language plpgsql security definer set search_path = public as $$
declare nxt uuid;
begin
  delete from public.server_members where server_id = p_id and user_id = auth.uid();
  if not found then return; end if;
  delete from public.server_keys where server_id = p_id and user_id = auth.uid();
  select user_id into nxt from public.server_members where server_id = p_id order by joined limit 1;
  if nxt is null then delete from public.servers where id = p_id;
  else update public.servers set owner = nxt where id = p_id and owner = auth.uid(); end if;
end $$;

create or replace function public.admin_delete_server(p_id uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Admins only'; end if;
  delete from public.servers where id = p_id;
end $$;

create or replace function public.mod_warn(target uuid, p_reason text) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.can_manage(auth.uid(), target) then raise exception 'Not allowed'; end if;
  p_reason := trim(coalesce(p_reason, ''));
  if char_length(p_reason) not between 3 and 200 then raise exception 'Write a reason of 3 to 200 characters.'; end if;
  insert into public.warnings (user_id, issued_by, reason) values (target, auth.uid(), p_reason);
  insert into public.system_msgs (user_id, text) values (target, 'Warning from staff: ' || p_reason);
end $$;

create or replace function public.mod_ban(target uuid, p_reason text) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.can_manage(auth.uid(), target) then raise exception 'Not allowed'; end if;
  p_reason := trim(coalesce(p_reason, ''));
  if char_length(p_reason) not between 3 and 200 then raise exception 'Write a reason of 3 to 200 characters.'; end if;
  update public.profiles set ban = jsonb_build_object('reason', p_reason, 'ts', public.ms_now(), 'by', auth.uid()::text) where id = target;
end $$;

create or replace function public.mod_unban(target uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.can_manage(auth.uid(), target) then raise exception 'Not allowed'; end if;
  update public.profiles set ban = null where id = target;
end $$;

create or replace function public.set_staff(target uuid, on_ boolean) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() or not public.can_manage(auth.uid(), target) then raise exception 'Not allowed'; end if;
  update public.profiles set role = case when on_ then 'staff' else 'user' end where id = target;
end $$;

create or replace function public._drop_user(uid uuid) returns void language plpgsql security definer set search_path = public as $$
declare s record; nxt uuid;
begin
  for s in select id from public.servers where owner = uid loop
    select user_id into nxt from public.server_members where server_id = s.id and user_id <> uid order by joined limit 1;
    if nxt is null then delete from public.servers where id = s.id; else update public.servers set owner = nxt where id = s.id; end if;
  end loop;
  delete from auth.users where id = uid;
end $$;

create or replace function public.admin_delete_user(target uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() or not public.can_manage(auth.uid(), target) then raise exception 'Not allowed'; end if;
  perform public._drop_user(target);
end $$;

create or replace function public.delete_my_account() returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Not signed in'; end if;
  if exists (select 1 from public.profiles where id = auth.uid() and protected) then
    raise exception 'The default admin account can''t be deleted.';
  end if;
  perform public._drop_user(auth.uid());
end $$;

create or replace function public.bug_set_status(p_id uuid, p_status text) returns void language plpgsql security definer set search_path = public as $$
declare b public.bugs; had boolean; has boolean; msg text;
begin
  if not public.is_admin() then raise exception 'Only admins can change a report''s status.'; end if;
  if p_status not in ('open', 'checking', 'fixed', 'nobug') then raise exception 'Unknown status'; end if;
  select * into b from public.bugs where id = p_id;
  if not found or b.status = p_status then return; end if;
  select hunter into had from public.profiles where id = b.reporter;
  update public.bugs set prev = case when p_status = 'fixed' then b.status else prev end, status = p_status,
         upd = public.ms_now(), handler = auth.uid() where id = p_id;
  select exists (select 1 from public.bugs where reporter = b.reporter and status = 'fixed') into has;
  update public.profiles set hunter = has where id = b.reporter;
  msg := case
    when b.status = 'fixed' then 'Your bug report “' || b.title || '” is no longer marked fixed.' || case when had and not has then ' The Bug hunter badge was removed.' else '' end
    when p_status = 'checking' then 'Staff are checking your bug report “' || b.title || '”.'
    when p_status = 'nobug' then 'Staff reviewed your report “' || b.title || '” and marked it as not a bug.'
    when p_status = 'fixed' then 'Your bug report “' || b.title || '” was fixed. Thank you!' || case when has and not had then ' You earned the Bug hunter badge.' else '' end
    else null end;
  if msg is not null then insert into public.system_msgs (user_id, text) values (b.reporter, msg); end if;
end $$;

create or replace function public.admin_emails() returns table (id uuid, email text) language sql stable security definer set search_path = public as
$$ select user_id, email from public.profile_private where public.is_staff() $$;

create or replace function public.admin_warnings() returns table (user_id uuid, n bigint) language sql stable security definer set search_path = public as
$$ select user_id, count(*) from public.warnings where public.is_staff() group by user_id $$;

-- Lock internal helpers away from the API, open the app's functions to signed-in users.
revoke execute on function public.username_free(text), public.login_email(text), public.is_staff(), public.is_admin(),
  public.is_banned(), public.is_member(uuid), public.can_manage(uuid, uuid), public.ms_now(), public.create_server(text),
  public.join_server(text), public.leave_server(uuid), public.admin_delete_server(uuid), public.mod_warn(uuid, text),
  public.mod_ban(uuid, text), public.mod_unban(uuid), public.set_staff(uuid, boolean), public._drop_user(uuid),
  public.admin_delete_user(uuid), public.delete_my_account(), public.bug_set_status(uuid, text), public.admin_emails(),
  public.admin_warnings(), public.handle_new_user(), public.bugs_rate(), public.bugs_ack(), public.profiles_guard()
  from public, anon, authenticated;
grant execute on function public.username_free(text), public.login_email(text) to anon, authenticated;
grant execute on function public.is_staff(), public.is_admin(), public.is_banned(), public.is_member(uuid), public.ms_now() to authenticated;
grant execute on function public.create_server(text), public.join_server(text), public.leave_server(uuid),
  public.admin_delete_server(uuid), public.mod_warn(uuid, text), public.mod_ban(uuid, text), public.mod_unban(uuid),
  public.set_staff(uuid, boolean), public.admin_delete_user(uuid), public.delete_my_account(),
  public.bug_set_status(uuid, text), public.admin_emails(), public.admin_warnings() to authenticated;

-- ---------- realtime nudges (the app also polls, so this is optional) ----------
do $$ begin
  alter publication supabase_realtime add table public.dm_msgs, public.server_msgs, public.system_msgs, public.server_members, public.server_keys, public.bugs, public.warnings;
exception when others then raise notice 'Realtime publication not updated: %', sqlerrm;
end $$;

-- ---------- default admin: username Devlearn ----------
-- The password is stored only as a bcrypt hash. Change it from Settings after your first login.
do $$
declare uid uuid;
begin
  select id into uid from auth.users where email = 'devlearn@tuso.app';
  if uid is null then
    uid := gen_random_uuid();
    insert into auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
        recovery_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
        confirmation_token, email_change, email_change_token_new, recovery_token)
      values ('00000000-0000-0000-0000-000000000000', uid, 'authenticated', 'authenticated', 'devlearn@tuso.app',
        '$2a$10$aDwTZqmgPXoEhTRpnh7P1.MgppxwQcOm.Nly6IIyfeF9r7xyL71Au', now(), now(), now(),
        '{"provider":"email","providers":["email"]}', '{"username":"devlearn","display":"Devlearn"}',
        now(), now(), '', '', '', '');
    insert into auth.identities (id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at)
      values (gen_random_uuid(), uid, jsonb_build_object('sub', uid::text, 'email', 'devlearn@tuso.app', 'email_verified', true),
        'email', uid::text, now(), now(), now());
  end if;
  -- also covers re-running this file, which recreates the tables but keeps the auth user
  insert into public.profiles (id, username, display) values (uid, 'devlearn', 'Devlearn') on conflict (id) do nothing;
  insert into public.profile_private (user_id, email) values (uid, 'devlearn@tuso.app') on conflict (user_id) do nothing;
  insert into public.system_msgs (user_id, tag, text) values (uid, 'welcome', 'Welcome to TuSo, Devlearn. This is your first direct message.' || E'\n\n' ||
    'Your direct messages and server chats are end-to-end encrypted, so only you and the people in the conversation can read them. Use “Find or start a conversation” to say hi.')
    on conflict (user_id, tag) where tag is not null do nothing;
  update public.profiles set role = 'admin', protected = true, username_login = true, banner = 1, bio = 'Runs TuSo.' where id = uid;
exception when others then
  raise notice 'Default admin was not created (%). Sign up normally, then run: update public.profiles set role = ''admin'', protected = true, username_login = true where username = ''devlearn'';', sqlerrm;
end $$;

-- =====================================================================
-- Server roles (same as roles.sql)
-- =====================================================================

create table if not exists public.server_roles (
  id uuid primary key default gen_random_uuid(),
  server_id uuid not null references public.servers (id) on delete cascade,
  name text not null check (char_length(name) between 1 and 24),
  color text not null default '#9aa0a6' check (color ~ '^#[0-9a-f]{6}$'),
  perms text[] not null default '{}',
  pos int not null default 1,
  hoist boolean not null default false,
  created bigint not null default public.ms_now()
);
create index if not exists server_roles_srv on public.server_roles (server_id);

create table if not exists public.member_roles (
  server_id uuid not null references public.servers (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  role_id uuid not null references public.server_roles (id) on delete cascade,
  primary key (user_id, role_id)
);
create index if not exists member_roles_srv on public.member_roles (server_id);

create table if not exists public.server_bans (
  server_id uuid not null references public.servers (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  reason text,
  by uuid references public.profiles (id) on delete set null,
  ts bigint not null default public.ms_now(),
  primary key (server_id, user_id)
);

-- ---------- helpers ----------
create or replace function public.srv_top(sid uuid, uid uuid) returns int language sql stable security definer set search_path = public as $$
  select case
    when exists (select 1 from public.servers where id = sid and owner = uid) then 1000000
    else coalesce((select max(r.pos) from public.member_roles mr join public.server_roles r on r.id = mr.role_id
                   where mr.server_id = sid and mr.user_id = uid), 0) end $$;

create or replace function public.srv_perm(sid uuid, uid uuid, perm text) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.server_members where server_id = sid and user_id = uid) and (
    exists (select 1 from public.servers where id = sid and owner = uid)
    or exists (select 1 from public.member_roles mr join public.server_roles r on r.id = mr.role_id
               where mr.server_id = sid and mr.user_id = uid and perm = any (r.perms))) $$;

create or replace function public.srv_outranks(sid uuid, actor uuid, target uuid) returns boolean language sql stable security definer set search_path = public as $$
  select actor <> target and public.srv_top(sid, actor) > public.srv_top(sid, target) $$;

create or replace function public.srv_perms_ok(p text[]) returns boolean language sql immutable as $$
  select coalesce(p <@ array['manage_roles','manage_messages','kick_members','ban_members','manage_server'], false) $$;

-- ---------- row level security ----------
alter table public.server_roles enable row level security;
alter table public.member_roles enable row level security;
alter table public.server_bans enable row level security;
drop policy if exists roles_read on public.server_roles;
create policy roles_read on public.server_roles for select to authenticated using (public.is_member(server_id) or public.is_admin());
drop policy if exists mroles_read on public.member_roles;
create policy mroles_read on public.member_roles for select to authenticated using (public.is_member(server_id) or public.is_admin());
drop policy if exists bans_read on public.server_bans;
create policy bans_read on public.server_bans for select to authenticated using (public.srv_perm(server_id, auth.uid(), 'ban_members') or public.is_admin());

-- managers can remove messages written by people below them
drop policy if exists smsg_delete on public.server_msgs;
create policy smsg_delete on public.server_msgs for delete to authenticated using (
  sender = auth.uid()
  or (public.srv_perm(server_id, auth.uid(), 'manage_messages') and public.srv_outranks(server_id, auth.uid(), sender)));

-- ---------- tidy up when someone leaves or is removed ----------
create or replace function public.member_gone() returns trigger language plpgsql security definer set search_path = public as $$
begin
  delete from public.member_roles where server_id = old.server_id and user_id = old.user_id;
  delete from public.server_keys where server_id = old.server_id and user_id = old.user_id;
  return old;
end $$;
drop trigger if exists member_gone on public.server_members;
create trigger member_gone after delete on public.server_members for each row execute function public.member_gone();

-- ---------- roles ----------
create or replace function public.role_create(p_server uuid, p_name text, p_color text, p_perms text[], p_hoist boolean)
returns public.server_roles language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); r public.server_roles; owner_ boolean;
begin
  if me is null or public.is_banned() or not public.srv_perm(p_server, me, 'manage_roles') then raise exception 'You can''t manage roles here.'; end if;
  p_name := trim(coalesce(p_name, ''));
  if char_length(p_name) not between 1 and 24 then raise exception 'Role names use 1 to 24 characters.'; end if;
  p_color := lower(coalesce(p_color, '#9aa0a6'));
  p_perms := coalesce(p_perms, '{}');
  if not public.srv_perms_ok(p_perms) then raise exception 'Unknown permission.'; end if;
  owner_ := exists (select 1 from public.servers where id = p_server and owner = me);
  if not owner_ and exists (select 1 from unnest(p_perms) x where not public.srv_perm(p_server, me, x)) then
    raise exception 'You can only give permissions you have yourself.'; end if;
  if (select count(*) from public.server_roles where server_id = p_server) >= 25 then raise exception 'A server can have up to 25 roles.'; end if;
  update public.server_roles set pos = pos + 1 where server_id = p_server;
  insert into public.server_roles (server_id, name, color, perms, pos, hoist) values (p_server, p_name, p_color, p_perms, 1, coalesce(p_hoist, false)) returning * into r;
  return r;
end $$;

create or replace function public.role_update(p_role uuid, p_name text, p_color text, p_perms text[], p_hoist boolean)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); r public.server_roles; owner_ boolean;
begin
  select * into r from public.server_roles where id = p_role;
  if not found then raise exception 'That role no longer exists.'; end if;
  if me is null or public.is_banned() or not public.srv_perm(r.server_id, me, 'manage_roles') or r.pos >= public.srv_top(r.server_id, me) then
    raise exception 'You can only edit roles below your own.'; end if;
  p_name := trim(coalesce(p_name, ''));
  if char_length(p_name) not between 1 and 24 then raise exception 'Role names use 1 to 24 characters.'; end if;
  p_perms := coalesce(p_perms, '{}');
  if not public.srv_perms_ok(p_perms) then raise exception 'Unknown permission.'; end if;
  owner_ := exists (select 1 from public.servers where id = r.server_id and owner = me);
  if not owner_ and exists (select 1 from unnest(p_perms) x where not (x = any (r.perms)) and not public.srv_perm(r.server_id, me, x)) then
    raise exception 'You can only give permissions you have yourself.'; end if;
  update public.server_roles set name = p_name, color = lower(coalesce(p_color, color)), perms = p_perms, hoist = coalesce(p_hoist, false) where id = p_role;
end $$;

create or replace function public.role_delete(p_role uuid) returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); r public.server_roles;
begin
  select * into r from public.server_roles where id = p_role;
  if not found then return; end if;
  if me is null or public.is_banned() or not public.srv_perm(r.server_id, me, 'manage_roles') or r.pos >= public.srv_top(r.server_id, me) then
    raise exception 'You can only delete roles below your own.'; end if;
  delete from public.server_roles where id = p_role;
  update public.server_roles s set pos = n.rn from (select id, row_number() over (order by pos) rn from public.server_roles where server_id = r.server_id) n where s.id = n.id;
end $$;

-- p_ids lists every role of the server, highest first
create or replace function public.role_reorder(p_server uuid, p_ids uuid[]) returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); n int; top_ int; i int; r public.server_roles;
begin
  if me is null or public.is_banned() or not public.srv_perm(p_server, me, 'manage_roles') then raise exception 'You can''t manage roles here.'; end if;
  select count(*) into n from public.server_roles where server_id = p_server;
  if coalesce(array_length(p_ids, 1), 0) <> n or (select count(distinct x) from unnest(p_ids) x) <> n
     or exists (select 1 from unnest(p_ids) x where not exists (select 1 from public.server_roles where id = x and server_id = p_server)) then
    raise exception 'The role list is out of date. Try again.'; end if;
  top_ := public.srv_top(p_server, me);
  for i in 1 .. n loop
    select * into r from public.server_roles where id = p_ids[i];
    if r.pos >= top_ and r.pos <> n - i + 1 then raise exception 'You can''t move roles at or above your own.'; end if;
  end loop;
  for i in 1 .. n loop update public.server_roles set pos = n - i + 1 where id = p_ids[i]; end loop;
end $$;

-- bulk: give or take one role for many members; returns how many changed
create or replace function public.role_assign(p_server uuid, p_users uuid[], p_role uuid, p_on boolean) returns int language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); r public.server_roles; u uuid; changed int := 0; c int;
begin
  select * into r from public.server_roles where id = p_role and server_id = p_server;
  if not found then raise exception 'That role no longer exists.'; end if;
  if me is null or public.is_banned() or not public.srv_perm(p_server, me, 'manage_roles') or r.pos >= public.srv_top(p_server, me) then
    raise exception 'You can only hand out roles below your own.'; end if;
  foreach u in array coalesce(p_users, '{}') loop
    continue when not exists (select 1 from public.server_members where server_id = p_server and user_id = u);
    continue when u <> me and not public.srv_outranks(p_server, me, u);
    if p_on then
      insert into public.member_roles (server_id, user_id, role_id) values (p_server, u, p_role) on conflict do nothing;
    else
      delete from public.member_roles where server_id = p_server and user_id = u and role_id = p_role;
    end if;
    get diagnostics c = row_count; changed := changed + c;
  end loop;
  return changed;
end $$;

-- ---------- kick, ban, rename ----------
create or replace function public.srv_kick(p_server uuid, target uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_banned() or not public.srv_perm(p_server, auth.uid(), 'kick_members') or not public.srv_outranks(p_server, auth.uid(), target) then
    raise exception 'You can''t remove this member.'; end if;
  delete from public.server_members where server_id = p_server and user_id = target;
end $$;

create or replace function public.srv_ban(p_server uuid, target uuid, p_reason text) returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_banned() or not public.srv_perm(p_server, auth.uid(), 'ban_members') or not public.srv_outranks(p_server, auth.uid(), target) then
    raise exception 'You can''t ban this member.'; end if;
  insert into public.server_bans (server_id, user_id, reason, by) values (p_server, target, left(trim(coalesce(p_reason, '')), 200), auth.uid())
    on conflict (server_id, user_id) do update set reason = excluded.reason, by = excluded.by, ts = public.ms_now();
  delete from public.server_members where server_id = p_server and user_id = target;
end $$;

create or replace function public.srv_unban(p_server uuid, target uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_banned() or not public.srv_perm(p_server, auth.uid(), 'ban_members') then raise exception 'You can''t manage bans here.'; end if;
  delete from public.server_bans where server_id = p_server and user_id = target;
end $$;

create or replace function public.srv_rename(p_server uuid, p_name text) returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_banned() or not public.srv_perm(p_server, auth.uid(), 'manage_server') then raise exception 'You can''t edit this server.'; end if;
  p_name := regexp_replace(trim(coalesce(p_name, '')), '\s+', ' ', 'g');
  if char_length(p_name) not between 2 and 32 then raise exception 'Use 2 to 32 characters.'; end if;
  update public.servers set name = p_name where id = p_server;
end $$;

-- banned people can't rejoin with the invite code
create or replace function public.join_server(p_code text) returns public.servers language plpgsql security definer set search_path = public as $$
declare s public.servers;
begin
  if auth.uid() is null or public.is_banned() then raise exception 'Not allowed'; end if;
  select * into s from public.servers where code = upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'));
  if not found then raise exception 'That invite code doesn''t match any server.'; end if;
  if exists (select 1 from public.server_bans where server_id = s.id and user_id = auth.uid()) then
    raise exception 'You are banned from this server.'; end if;
  if exists (select 1 from public.server_members where server_id = s.id and user_id = auth.uid()) then
    raise exception 'You are already in this server.';
  end if;
  if (select count(*) from public.server_members where user_id = auth.uid()) >= 100 then
    raise exception 'You are in 100 servers, the most allowed. Leave one to make room.';
  end if;
  insert into public.server_members (server_id, user_id) values (s.id, auth.uid());
  return s;
end $$;

-- ---------- privileges ----------
revoke all on public.server_roles, public.member_roles, public.server_bans from anon, authenticated;
grant select on public.server_roles, public.member_roles, public.server_bans to authenticated;
revoke execute on function public.srv_top(uuid, uuid), public.srv_perm(uuid, uuid, text), public.srv_outranks(uuid, uuid, uuid), public.srv_perms_ok(text[]),
  public.member_gone(), public.role_create(uuid, text, text, text[], boolean), public.role_update(uuid, text, text, text[], boolean),
  public.role_delete(uuid), public.role_reorder(uuid, uuid[]), public.role_assign(uuid, uuid[], uuid, boolean),
  public.srv_kick(uuid, uuid), public.srv_ban(uuid, uuid, text), public.srv_unban(uuid, uuid), public.srv_rename(uuid, text),
  public.join_server(text) from public, anon, authenticated;
grant execute on function public.srv_top(uuid, uuid), public.srv_perm(uuid, uuid, text), public.srv_outranks(uuid, uuid, uuid), public.srv_perms_ok(text[]),
  public.role_create(uuid, text, text, text[], boolean), public.role_update(uuid, text, text, text[], boolean),
  public.role_delete(uuid), public.role_reorder(uuid, uuid[]), public.role_assign(uuid, uuid[], uuid, boolean),
  public.srv_kick(uuid, uuid), public.srv_ban(uuid, uuid, text), public.srv_unban(uuid, uuid), public.srv_rename(uuid, text),
  public.join_server(text) to authenticated;

-- ---------- realtime nudges (optional; the app also polls) ----------
do $$ begin alter publication supabase_realtime add table public.server_roles; exception when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.member_roles; exception when others then null; end $$;
