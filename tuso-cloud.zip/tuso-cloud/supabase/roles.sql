-- =====================================================================
-- TuSo server roles. ADDITIVE and safe to re-run: it never touches existing data.
-- Already running TuSo? Paste just this file into the SQL editor and run it.
-- (schema.sql contains this file at the bottom, so a fresh install gets it too.)
-- =====================================================================

create table if not exists public.server_roles (
  id uuid primary key default gen_random_uuid(),
  server_id uuid not null references public.servers (id) on delete cascade,
  name text not null check (char_length(name) between 1 and 24),
  color text not null default '#9aa0a6' check (color ~ '^#[0-9a-f]{6}$'),
  perms text[] not null default '{}',
  pos int not null default 1,
  hoist boolean not null default false,
  created bigint not null default public.ms_now()
);
create index if not exists server_roles_srv on public.server_roles (server_id);

create table if not exists public.member_roles (
  server_id uuid not null references public.servers (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  role_id uuid not null references public.server_roles (id) on delete cascade,
  primary key (user_id, role_id)
);
create index if not exists member_roles_srv on public.member_roles (server_id);

create table if not exists public.server_bans (
  server_id uuid not null references public.servers (id) on delete cascade,
  user_id uuid not null references public.profiles (id) on delete cascade,
  reason text,
  by uuid references public.profiles (id) on delete set null,
  ts bigint not null default public.ms_now(),
  primary key (server_id, user_id)
);

-- ---------- helpers ----------
create or replace function public.srv_top(sid uuid, uid uuid) returns int language sql stable security definer set search_path = public as $$
  select case
    when exists (select 1 from public.servers where id = sid and owner = uid) then 1000000
    else coalesce((select max(r.pos) from public.member_roles mr join public.server_roles r on r.id = mr.role_id
                   where mr.server_id = sid and mr.user_id = uid), 0) end $$;

create or replace function public.srv_perm(sid uuid, uid uuid, perm text) returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.server_members where server_id = sid and user_id = uid) and (
    exists (select 1 from public.servers where id = sid and owner = uid)
    or exists (select 1 from public.member_roles mr join public.server_roles r on r.id = mr.role_id
               where mr.server_id = sid and mr.user_id = uid and perm = any (r.perms))) $$;

create or replace function public.srv_outranks(sid uuid, actor uuid, target uuid) returns boolean language sql stable security definer set search_path = public as $$
  select actor <> target and public.srv_top(sid, actor) > public.srv_top(sid, target) $$;

create or replace function public.srv_perms_ok(p text[]) returns boolean language sql immutable as $$
  select coalesce(p <@ array['manage_roles','manage_messages','kick_members','ban_members','manage_server'], false) $$;

-- ---------- row level security ----------
alter table public.server_roles enable row level security;
alter table public.member_roles enable row level security;
alter table public.server_bans enable row level security;
drop policy if exists roles_read on public.server_roles;
create policy roles_read on public.server_roles for select to authenticated using (public.is_member(server_id) or public.is_admin());
drop policy if exists mroles_read on public.member_roles;
create policy mroles_read on public.member_roles for select to authenticated using (public.is_member(server_id) or public.is_admin());
drop policy if exists bans_read on public.server_bans;
create policy bans_read on public.server_bans for select to authenticated using (public.srv_perm(server_id, auth.uid(), 'ban_members') or public.is_admin());

-- managers can remove messages written by people below them
drop policy if exists smsg_delete on public.server_msgs;
create policy smsg_delete on public.server_msgs for delete to authenticated using (
  sender = auth.uid()
  or (public.srv_perm(server_id, auth.uid(), 'manage_messages') and public.srv_outranks(server_id, auth.uid(), sender)));

-- ---------- tidy up when someone leaves or is removed ----------
create or replace function public.member_gone() returns trigger language plpgsql security definer set search_path = public as $$
begin
  delete from public.member_roles where server_id = old.server_id and user_id = old.user_id;
  delete from public.server_keys where server_id = old.server_id and user_id = old.user_id;
  return old;
end $$;
drop trigger if exists member_gone on public.server_members;
create trigger member_gone after delete on public.server_members for each row execute function public.member_gone();

-- ---------- roles ----------
create or replace function public.role_create(p_server uuid, p_name text, p_color text, p_perms text[], p_hoist boolean)
returns public.server_roles language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); r public.server_roles; owner_ boolean;
begin
  if me is null or public.is_banned() or not public.srv_perm(p_server, me, 'manage_roles') then raise exception 'You can''t manage roles here.'; end if;
  p_name := trim(coalesce(p_name, ''));
  if char_length(p_name) not between 1 and 24 then raise exception 'Role names use 1 to 24 characters.'; end if;
  p_color := lower(coalesce(p_color, '#9aa0a6'));
  p_perms := coalesce(p_perms, '{}');
  if not public.srv_perms_ok(p_perms) then raise exception 'Unknown permission.'; end if;
  owner_ := exists (select 1 from public.servers where id = p_server and owner = me);
  if not owner_ and exists (select 1 from unnest(p_perms) x where not public.srv_perm(p_server, me, x)) then
    raise exception 'You can only give permissions you have yourself.'; end if;
  if (select count(*) from public.server_roles where server_id = p_server) >= 25 then raise exception 'A server can have up to 25 roles.'; end if;
  update public.server_roles set pos = pos + 1 where server_id = p_server;
  insert into public.server_roles (server_id, name, color, perms, pos, hoist) values (p_server, p_name, p_color, p_perms, 1, coalesce(p_hoist, false)) returning * into r;
  return r;
end $$;

create or replace function public.role_update(p_role uuid, p_name text, p_color text, p_perms text[], p_hoist boolean)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); r public.server_roles; owner_ boolean;
begin
  select * into r from public.server_roles where id = p_role;
  if not found then raise exception 'That role no longer exists.'; end if;
  if me is null or public.is_banned() or not public.srv_perm(r.server_id, me, 'manage_roles') or r.pos >= public.srv_top(r.server_id, me) then
    raise exception 'You can only edit roles below your own.'; end if;
  p_name := trim(coalesce(p_name, ''));
  if char_length(p_name) not between 1 and 24 then raise exception 'Role names use 1 to 24 characters.'; end if;
  p_perms := coalesce(p_perms, '{}');
  if not public.srv_perms_ok(p_perms) then raise exception 'Unknown permission.'; end if;
  owner_ := exists (select 1 from public.servers where id = r.server_id and owner = me);
  if not owner_ and exists (select 1 from unnest(p_perms) x where not (x = any (r.perms)) and not public.srv_perm(r.server_id, me, x)) then
    raise exception 'You can only give permissions you have yourself.'; end if;
  update public.server_roles set name = p_name, color = lower(coalesce(p_color, color)), perms = p_perms, hoist = coalesce(p_hoist, false) where id = p_role;
end $$;

create or replace function public.role_delete(p_role uuid) returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); r public.server_roles;
begin
  select * into r from public.server_roles where id = p_role;
  if not found then return; end if;
  if me is null or public.is_banned() or not public.srv_perm(r.server_id, me, 'manage_roles') or r.pos >= public.srv_top(r.server_id, me) then
    raise exception 'You can only delete roles below your own.'; end if;
  delete from public.server_roles where id = p_role;
  update public.server_roles s set pos = n.rn from (select id, row_number() over (order by pos) rn from public.server_roles where server_id = r.server_id) n where s.id = n.id;
end $$;

-- p_ids lists every role of the server, highest first
create or replace function public.role_reorder(p_server uuid, p_ids uuid[]) returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); n int; top_ int; i int; r public.server_roles;
begin
  if me is null or public.is_banned() or not public.srv_perm(p_server, me, 'manage_roles') then raise exception 'You can''t manage roles here.'; end if;
  select count(*) into n from public.server_roles where server_id = p_server;
  if coalesce(array_length(p_ids, 1), 0) <> n or (select count(distinct x) from unnest(p_ids) x) <> n
     or exists (select 1 from unnest(p_ids) x where not exists (select 1 from public.server_roles where id = x and server_id = p_server)) then
    raise exception 'The role list is out of date. Try again.'; end if;
  top_ := public.srv_top(p_server, me);
  for i in 1 .. n loop
    select * into r from public.server_roles where id = p_ids[i];
    if r.pos >= top_ and r.pos <> n - i + 1 then raise exception 'You can''t move roles at or above your own.'; end if;
  end loop;
  for i in 1 .. n loop update public.server_roles set pos = n - i + 1 where id = p_ids[i]; end loop;
end $$;

-- bulk: give or take one role for many members; returns how many changed
create or replace function public.role_assign(p_server uuid, p_users uuid[], p_role uuid, p_on boolean) returns int language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); r public.server_roles; u uuid; changed int := 0; c int;
begin
  select * into r from public.server_roles where id = p_role and server_id = p_server;
  if not found then raise exception 'That role no longer exists.'; end if;
  if me is null or public.is_banned() or not public.srv_perm(p_server, me, 'manage_roles') or r.pos >= public.srv_top(p_server, me) then
    raise exception 'You can only hand out roles below your own.'; end if;
  foreach u in array coalesce(p_users, '{}') loop
    continue when not exists (select 1 from public.server_members where server_id = p_server and user_id = u);
    continue when u <> me and not public.srv_outranks(p_server, me, u);
    if p_on then
      insert into public.member_roles (server_id, user_id, role_id) values (p_server, u, p_role) on conflict do nothing;
    else
      delete from public.member_roles where server_id = p_server and user_id = u and role_id = p_role;
    end if;
    get diagnostics c = row_count; changed := changed + c;
  end loop;
  return changed;
end $$;

-- ---------- kick, ban, rename ----------
create or replace function public.srv_kick(p_server uuid, target uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_banned() or not public.srv_perm(p_server, auth.uid(), 'kick_members') or not public.srv_outranks(p_server, auth.uid(), target) then
    raise exception 'You can''t remove this member.'; end if;
  delete from public.server_members where server_id = p_server and user_id = target;
end $$;

create or replace function public.srv_ban(p_server uuid, target uuid, p_reason text) returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_banned() or not public.srv_perm(p_server, auth.uid(), 'ban_members') or not public.srv_outranks(p_server, auth.uid(), target) then
    raise exception 'You can''t ban this member.'; end if;
  insert into public.server_bans (server_id, user_id, reason, by) values (p_server, target, left(trim(coalesce(p_reason, '')), 200), auth.uid())
    on conflict (server_id, user_id) do update set reason = excluded.reason, by = excluded.by, ts = public.ms_now();
  delete from public.server_members where server_id = p_server and user_id = target;
end $$;

create or replace function public.srv_unban(p_server uuid, target uuid) returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_banned() or not public.srv_perm(p_server, auth.uid(), 'ban_members') then raise exception 'You can''t manage bans here.'; end if;
  delete from public.server_bans where server_id = p_server and user_id = target;
end $$;

create or replace function public.srv_rename(p_server uuid, p_name text) returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_banned() or not public.srv_perm(p_server, auth.uid(), 'manage_server') then raise exception 'You can''t edit this server.'; end if;
  p_name := regexp_replace(trim(coalesce(p_name, '')), '\s+', ' ', 'g');
  if char_length(p_name) not between 2 and 32 then raise exception 'Use 2 to 32 characters.'; end if;
  update public.servers set name = p_name where id = p_server;
end $$;

-- banned people can't rejoin with the invite code
create or replace function public.join_server(p_code text) returns public.servers language plpgsql security definer set search_path = public as $$
declare s public.servers;
begin
  if auth.uid() is null or public.is_banned() then raise exception 'Not allowed'; end if;
  select * into s from public.servers where code = upper(regexp_replace(coalesce(p_code, ''), '[^A-Za-z0-9]', '', 'g'));
  if not found then raise exception 'That invite code doesn''t match any server.'; end if;
  if exists (select 1 from public.server_bans where server_id = s.id and user_id = auth.uid()) then
    raise exception 'You are banned from this server.'; end if;
  if exists (select 1 from public.server_members where server_id = s.id and user_id = auth.uid()) then
    raise exception 'You are already in this server.';
  end if;
  if (select count(*) from public.server_members where user_id = auth.uid()) >= 100 then
    raise exception 'You are in 100 servers, the most allowed. Leave one to make room.';
  end if;
  insert into public.server_members (server_id, user_id) values (s.id, auth.uid());
  return s;
end $$;

-- ---------- privileges ----------
revoke all on public.server_roles, public.member_roles, public.server_bans from anon, authenticated;
grant select on public.server_roles, public.member_roles, public.server_bans to authenticated;
revoke execute on function public.srv_top(uuid, uuid), public.srv_perm(uuid, uuid, text), public.srv_outranks(uuid, uuid, uuid), public.srv_perms_ok(text[]),
  public.member_gone(), public.role_create(uuid, text, text, text[], boolean), public.role_update(uuid, text, text, text[], boolean),
  public.role_delete(uuid), public.role_reorder(uuid, uuid[]), public.role_assign(uuid, uuid[], uuid, boolean),
  public.srv_kick(uuid, uuid), public.srv_ban(uuid, uuid, text), public.srv_unban(uuid, uuid), public.srv_rename(uuid, text),
  public.join_server(text) from public, anon, authenticated;
grant execute on function public.srv_top(uuid, uuid), public.srv_perm(uuid, uuid, text), public.srv_outranks(uuid, uuid, uuid), public.srv_perms_ok(text[]),
  public.role_create(uuid, text, text, text[], boolean), public.role_update(uuid, text, text, text[], boolean),
  public.role_delete(uuid), public.role_reorder(uuid, uuid[]), public.role_assign(uuid, uuid[], uuid, boolean),
  public.srv_kick(uuid, uuid), public.srv_ban(uuid, uuid, text), public.srv_unban(uuid, uuid), public.srv_rename(uuid, text),
  public.join_server(text) to authenticated;

-- ---------- realtime nudges (optional; the app also polls) ----------
do $$ begin alter publication supabase_realtime add table public.server_roles; exception when others then null; end $$;
do $$ begin alter publication supabase_realtime add table public.member_roles; exception when others then null; end $$;
